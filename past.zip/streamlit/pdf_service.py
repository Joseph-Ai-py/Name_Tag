from __future__ import annotations

from urllib.parse import quote

from pdf_builder import assemble_html

from pdf_builder import (
    build_css,
	build_cover,
    build_section_o_mvb,
    build_a1_philosophy,
    build_a2_core_identity,
    build_a3_story,
    build_a4_verbal_toolkit,
    build_a5_positioning,
    build_a6_promise,
    build_b1_target_profile,
    build_b2_persona_detail,
    build_b3_customer_journey,
    build_b4_customer_swot,
    build_b5_business_model,
    build_c1_color_system,
    build_c2_typography,
    build_c3_visual_mood,
    build_d_logo_identity,
    build_e_character_guide,
    get_absolute_path
)

def generate_pdf_bytes(
	brand_info: dict,
	data_a: dict,
	data_b: dict,
	data_c: dict,
	data_de: dict,
    brand_dna: dict | None = None,
    integrity_report: dict | None = None,
    decision_traces: list[dict] | None = None,
) -> bytes:
    try:
        from weasyprint import HTML
    except (ImportError, OSError) as exc:
        print(f"[PDF] WeasyPrint import failed: {exc}")
        raise RuntimeError(
            "WeasyPrint를 불러오지 못했습니다. PDF 실행 환경의 WeasyPrint 및 시스템 라이브러리를 확인해 주세요."
        ) from exc

    try:
        html_content = assemble_html(brand_info, data_a, data_b, data_c, data_de, brand_dna, integrity_report, decision_traces)
        print(f"[PDF] HTML build completed ({len(html_content)} chars)")
    except Exception as exc:
        print(f"[PDF] HTML generation failed: {exc}")
        raise RuntimeError("PDF용 HTML을 생성하지 못했습니다.") from exc

    try:
        pdf_bytes = HTML(
            string=html_content,
            base_url=get_absolute_path('/assets/'),
        ).write_pdf()
        print(f"[PDF] rendering completed ({len(pdf_bytes)} bytes)")
        return pdf_bytes
    except Exception as exc:
        print(f"[PDF] PDF rendering failed: {exc}")
        raise RuntimeError("PDF 렌더링에 실패했습니다. 이미지 경로와 PDF 실행 환경을 확인해 주세요.") from exc


def build_download_filename(brand_name: str) -> str:
	return f"nametag_{brand_name}_guideline.pdf"


def build_content_disposition(brand_name: str) -> str:
	encoded_filename = quote(build_download_filename(brand_name))
	return f"attachment; filename*=utf-8''{encoded_filename}"

def generate_o_only_html(brand_info: dict) -> str:
    """PDF 변환 없이 HTML 문자열만 렌더링하여 반환합니다 (Section O 빠른 미리보기용)"""
    
    # 브랜드 컬러 적용
    seed_color = brand_info.get('seed_color', '#000000') if brand_info else '#000000'
    sd_color = "#3A3A3A"
    sl_color = "#F8F9FA"

    # 기본 CSS 로드 및 미리보기 전용 껍질(Wrapper) CSS 추가
    base_css = build_css(seed_color, sd_color, sl_color)
    preview_css = base_css + """
    body {
        max-width: 210mm;
        margin: 0 auto;
        background-color: #ffffff;
        box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        padding: 40px;
        overflow-x: hidden;
    }
    """

    html = f"""<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8">
  <link href="https://fonts.googleapis.com/css2?family=Gothic+A1:wght@400;800&family=Noto+Sans+KR:wght@400;500;700&family=Noto+Serif+KR:wght@400;600;700&display=swap" rel="stylesheet">
  <style>{preview_css}</style>
</head>
<body>
"""
    # 🌟 표지와 Section O 내용을 조립합니다
    if brand_info:
        html += build_cover(brand_info)
        html += build_section_o_mvb(brand_info)

    html += "</body>\n</html>"

    return html

def generate_a_only_html(brand_info: dict, data_a: dict) -> str:
    """PDF 변환 없이 HTML 문자열만 렌더링하여 반환합니다 (빠른 미리보기용)"""
    
    if data_a and 'data_a' in data_a:
        data_a = data_a['data_a']

    seed_color = brand_info.get('seed_color', '#000000') if brand_info else '#000000'
    sd_color = "#3A3A3A"
    sl_color = "#F8F9FA"

    # 기본 CSS 로드
    base_css = build_css(seed_color, sd_color, sl_color)
    
    preview_css = base_css + """
    body {
        max-width: 210mm;
        margin: 0 auto;
        background-color: #ffffff;
        box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        padding: 40px;
        overflow-x: hidden;
    }
    """

    html = f"""<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8">
  <link href="https://fonts.googleapis.com/css2?family=Gothic+A1:wght@400;800&family=Noto+Sans+KR:wght@400;500;700&family=Noto+Serif+KR:wght@400;600;700&display=swap" rel="stylesheet">
  <style>{preview_css}</style>
</head>
<body>
"""
    if data_a:
        html += build_a1_philosophy(data_a)
        html += build_a2_core_identity(data_a)
        html += build_a3_story(data_a)
        html += build_a4_verbal_toolkit(data_a)
        html += build_a5_positioning(data_a)
        html += build_a6_promise(data_a)

    html += "</body>\n</html>"

    return html

def generate_b_only_html(brand_info: dict, data_b: dict) -> str:
    """Section B 미리보기용 HTML 생성"""
    if data_b and 'data_b' in data_b: data_b = data_b['data_b']

    seed_color = brand_info.get('seed_color', '#000000') if brand_info else '#000000'
    sd_color, sl_color = "#3A3A3A", "#F8F9FA"

    base_css = build_css(seed_color, sd_color, sl_color)
    preview_css = base_css + "\nbody { max-width: 210mm; margin: 0 auto; background-color: #ffffff; box-shadow: 0 4px 12px rgba(0,0,0,0.1); padding: 40px; overflow-x: hidden; }"

    html = f"""<!DOCTYPE html>\n<html lang="ko">\n<head>\n<meta charset="UTF-8">\n<style>{preview_css}</style>\n</head>\n<body>\n"""
    
    if data_b:
        html += build_b1_target_profile(data_b)
        html += build_b2_persona_detail(data_b)
        html += build_b3_customer_journey(data_b)
        html += build_b4_customer_swot(data_b)
        html += build_b5_business_model(data_b)
        
    html += "</body>\n</html>"
    return html


def generate_c_only_html(brand_info: dict, data_c: dict) -> str:
    """Section C 미리보기용 HTML 생성"""
    if data_c and 'data_c' in data_c: data_c = data_c['data_c']

    seed_color = brand_info.get('seed_color', '#000000') if brand_info else '#000000'
    sd_color, sl_color = "#3A3A3A", "#F8F9FA"

    # Section C에서 추출된 팔레트가 있다면 테마 컬러에 반영합니다.
    if data_c:
        palette = data_c.get('color_palette', [])
        if isinstance(palette, list):
            for c in palette:
                role = c.get('role', '').lower()
                if 'primary' in role: sl_color = c.get('hex_code', sl_color)
                elif 'secondary' in role or 'accent' in role: sd_color = c.get('hex_code', sd_color)

    base_css = build_css(seed_color, sd_color, sl_color)
    preview_css = base_css + "\nbody { max-width: 210mm; margin: 0 auto; background-color: #ffffff; box-shadow: 0 4px 12px rgba(0,0,0,0.1); padding: 40px; overflow-x: hidden; }"

    html = f"""<!DOCTYPE html>\n<html lang="ko">\n<head>\n<meta charset="UTF-8">\n<style>{preview_css}</style>\n</head>\n<body>\n"""
    
    if data_c:
        html += build_c1_color_system(data_c)
        html += build_c2_typography(data_c)
        html += build_c3_visual_mood(data_c)
        
    html += "</body>\n</html>"
    return html

def generate_de_only_html(brand_info: dict, data_c: dict, data_de: dict) -> str:
    """Section DE 미리보기용 HTML 생성"""
    if data_c and 'data_c' in data_c: data_c = data_c['data_c']
    if data_de and 'data_de' in data_de: data_de = data_de['data_de']

    seed_color = brand_info.get('seed_color', '#000000') if brand_info else '#000000'
    sd_color, sl_color = "#3A3A3A", "#F8F9FA"

    # C의 컬러 시스템을 가져와서 통일감을 줍니다.
    if data_c:
        palette = data_c.get('color_palette', [])
        if isinstance(palette, list):
            for c in palette:
                role = c.get('role', '').lower()
                if 'primary' in role: sl_color = c.get('hex_code', sl_color)
                elif 'secondary' in role or 'accent' in role: sd_color = c.get('hex_code', sd_color)

    base_css = build_css(seed_color, sd_color, sl_color)
    preview_css = base_css + "\nbody { max-width: 210mm; margin: 0 auto; background-color: #ffffff; box-shadow: 0 4px 12px rgba(0,0,0,0.1); padding: 40px; overflow-x: hidden; }"

    # 로고 및 캐릭터 이미지 경로 추출
    logo_path = get_absolute_path(data_de.get('logo_path', None)) if data_de else None
    print(f'logo paht : {logo_path}')
    char_path = get_absolute_path(data_de.get('char_path', None)) if data_de else None
    print(f'char paht : {logo_path}')

    html = f"""<!DOCTYPE html>\n<html lang="ko">\n<head>\n<meta charset="UTF-8">\n<style>{preview_css}</style>\n</head>\n<body>\n"""
    
    if data_de:
        html += build_d_logo_identity(data_de, logo_path)
        html += build_e_character_guide(data_de, logo_path)
        # print(f"html_1 = {html}")
        
    html += "</body>\n</html>"
    print(f"html_2 = {html}")
    return html


# 구현 계획서 (plan.md)

## 개요
요청된 개선사항을 단계별로 정리한 실행 계획서입니다. 현재까지 인터뷰 건너뛰기, 앞뒤 이동 보존, 직접 입력, 응답 미리보기 기능을 프론트엔드에 먼저 적용했습니다. 아래에 완료된 항목과 5번(섹션별 재생성 버튼) 고도화 계획, 남은 작업을 정리합니다.

## 현재 진행 현황

### 완료
- 인터뷰 건너뛰기, 앞뒤 이동 보존, 직접 입력, 선택 전 미리보기, 섹션별 재생성, 선택값 영구화, 명시적 `다음` 버튼, Section O HTML 빌더를 반영했습니다.
- `InterviewSnapshot`의 `user_inputs` 저장/복원과 `appliedSelections` 영구화를 완료했고, 관련 Vitest 테스트도 통과했습니다.
- DE 로고/캐릭터 분리 생성 엔드포인트와 프론트 연결, 업로드 라우터/모델 추가, 업로드 sqlite 영구화까지 반영했습니다.
- PDF 스트리밍 응답과 CORS `Content-Disposition` 노출 설정을 반영했고, 프론트 빌드 및 단위 테스트, Playwright 스캐폴딩도 마쳤습니다.

### 진행 중 / 확인 필요
- 백엔드 import 경로가 아직 환경에 따라 흔들릴 수 있어, `backend/main.py`와 `backend/routers/section_a.py`의 import 경로를 다시 확인해야 합니다.
- 섹션별 HTML 미리조합과 PDF 미리보기 UI/사이드바 편집 흐름은 아직 고도화가 필요합니다.
- DE 이미지 분리 워크플로(로고/캐릭터 분리 생성)는 스켈레톤 이후 후속 검증이 필요합니다.

### 검증 메모
- 프론트 빌드와 Vitest는 통과 상태입니다.
- 업로드 sqlite 저장/조회와 PDF 응답 관련 변경은 스모크 검증을 거쳤습니다.
- Playwright는 스캐폴딩만 되어 있고 실제 시나리오 자동화는 다음 단계입니다.

## 다음 작업 우선순위
1. 섹션별 HTML 미리조합 및 PDF 미리보기 UI + 사이드바 에디터 정리
2. DE: 로고/캐릭터 분리 이미지 생성 버튼 및 백엔드 워크플로 고도화
3. 백엔드 import 경로 재확인 및 실행 안정화
4. Playwright 기반 E2E 시나리오 작성

## 5번(섹션별 재생성 버튼) - 개선 및 구현 계획
목표: 사용자가 섹션별(브랜드명, 의미, 슬로건, 스토리 등)로 재생성할 수 있게 하되, 이미 사용자가 선택한 값이 있으면 이를 컨텍스트로 반영하여 새로운 후보를 생성한다.

설계(프론트):
- UI: 섹션 결과 영역(예: SectionA 결과 카드)에 `재생성` 버튼을 항목별(브랜드명/의미/슬로건/스토리)로 추가.
- 동작: 사용자가 `재생성` 클릭 시 현재 `store`에서 해당 섹션의 `selectedValues`와 `userInputs`(직접입력)를 수집하여 API로 보냄.
- UX: 재생성 요청 전 간단한 확인 모달(선택 반영 여부 토글: "현재 선택을 컨텍스트로 사용") 제공.

설계(백엔드):
- 엔드포인트: `POST /api/section-{x}/re-generate` (예: `/section-a/re-generate`) 추가.
- 요청 페이로드 예시:
	{
		"brand_info": {...},
		"context": {
			"selected": { "brand_name": "X", "slogan": "Y", ... },
			"user_inputs": { "brand_story": "직접입력 내용" }
		},
		"target": "brand_name"  // 재생성 대상 필드
	}
- 동작: 백엔드는 전달된 `context`를 프롬프트에 포함해 모델 호출(기존 prompt 템플릿을 부분 변형). 반환된 후보 중 클라이언트가 다시 선택할 수 있게 JSON으로 반환.

데이터 플로우/보존:
- 재생성은 원본 전체 재생성(섹션 전체) 대신 대상 필드만 갱신해도 됨(백엔드에서 유연하게 처리). 클라이언트는 기존 `selectedValues`를 덮어쓸지 여부를 선택하게 함.
- 재생성 결과는 `store`와 `interviewSnapshots`에 반영하여 뒤로/앞 복원에도 영향 없음.

테스트/검증 기준:
- 재생성 클릭 -> 2초 이내에 API 요청 전송(또는 로딩 표시) 및 응답 수신.
- 응답 JSON이 예상 필드(예: `brand_name_candidates`)를 포함.
- 사용자가 재생성된 항목을 선택하면 `store`에 정상 반영되고 이후 페이지 이동 시 보존.

## 개발/실행 명령
```bash
# 프론트 개발
cd frontend
npm run dev

# 백엔드 개발
cd backend
source .venv/bin/activate  # 또는 가상환경 활성화
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

---

이 파일은 현재 완료된 기능과 다음 우선순위를 한 번에 볼 수 있게 정리한 버전입니다. 원하시면 다음에는 여기에 맞춰 `WORK_LOG_2026-05-31.md`도 같은 톤으로 압축 정리하겠습니다.

## Phase 1 전용 실행 계획 (문서 기준, 코드 미수정)

### 범위
- 대상: `backend/`, `frontend/`
- 제외: `V2/`, `streamlit/`
- 현재 단계: 계획 수립 및 체크리스트 확정만 수행
- 비범위: 코드 변경, 테스트 실행, 브랜치/커밋/PR 작업

### 목표 (버그 1.1~1.4)
1. O 인터뷰 입력 반영 누락 수정 계획 수립
2. O 재생성 `brand_info` 오참조 수정 계획 수립
3. 인터뷰 질문 수/선택지/ID 검증 규칙 통일 계획 수립
4. B1/B2 `strategic_reasoning` 키 충돌 해소 계획 수립

### 구현 순서(실행 시)
1. 사전 확인
- 관련 파일을 먼저 읽고 현재 상태가 문서와 일치하는지 검증
- `pydantic` 메이저 버전 확인(v2 전제)

2. 인터뷰 스키마 강화
- `backend/schemas/schema_interview.py`
- `options` 길이 4 고정, 질문 수 5~10 제한
- `required_question_count == len(questions)` 검증
- `question_id` 중복 금지 검증

3. O 인터뷰 입력 전달 보정
- `backend/routers/section_o.py`의 `/interview` 요청 모델을 `OInterviewRequest`로 고정
- `backend/prompts/nametag_prompts.py`의 `get_O_interview_prompt(brand_data: dict)`로 변경
- 프롬프트에 업종/감성/타겟/키워드 명시 주입

4. O 재생성 오참조 수정
- `backend/routers/section_o.py`의 `/re-generate`에서 `req.brand_data` 사용
- 재생성 프롬프트에 `brand_data`, `context`, `target` 포함

5. 인터뷰 프롬프트 규칙 통일
- O/A/B/C/DE 인터뷰 프롬프트에 동일 규칙 문구 반영
- 예시 JSON은 모두 5개 이상 질문, 질문당 4개 선택지로 통일
- 가능하면 규칙 상수(`INTERVIEW_RULES`) 공유

6. B 단계 키 충돌 해소
- B1: `target_strategy_reasoning`
- B2: `journey_strategy_reasoning`
- `backend/schemas/schema_b.py` 추가 후 B 응답 검증
- 병합 시 충돌 감지 로그(또는 예외) 추가

7. 테스트 추가(오프라인 통과 가능)
- `backend/tests/`에 스키마/프롬프트/병합 테스트 추가
- 외부 Gemini 호출 없이 단위 테스트만 구성

### 완료 조건 (실행 시)
- `python -m pytest backend/tests` 통과
- `backend/routers/section_o.py`에 `req.brand_info` 잔존 없음
- `backend/prompts`에 `required_question_count": 1` 잔존 없음
- 5개 인터뷰 프롬프트가 동일 규칙 상수를 공유
- 프론트 수정 발생 시 `frontend` 빌드 통과

### 리스크 / 결정 필요
- `request_gemini_with_schema`의 스키마 실패 재시도 정책(최대 2회) 적용 여부는 별도 승인 후 반영
- 프론트 파라미터명(`brandInfo` vs `brandData`)은 서버 바디 키(`brand_data`)와의 정합성을 우선 검증 후 최소 수정

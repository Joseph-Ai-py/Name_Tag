from sqlalchemy import create_engine

from app.config import get_settings


settings = get_settings()

connect_args = {}

if settings.database_url.startswith("sqlite"):
    connect_args = {
        "check_same_thread": False,
    }

engine = create_engine(
    settings.database_url,
    connect_args=connect_args,
)